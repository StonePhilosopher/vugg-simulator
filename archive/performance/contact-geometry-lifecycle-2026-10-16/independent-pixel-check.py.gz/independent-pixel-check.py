import json
import sys
from pathlib import Path
from itertools import combinations
import PIL
from PIL import Image
import numpy as np

root = Path('archive/performance/contact-geometry-lifecycle-2026-10-16')
summary = json.loads((root / 'summary.json').read_text())
results = []

def compare(a, b):
    delta = np.abs(a[:, :, :3] - b[:, :, :3])
    return {
        'max_rgb_delta': int(delta.max()),
        'changed_pixels': int(np.any(delta != 0, axis=2).sum()),
        'alpha_equal': bool(np.array_equal(a[:, :, 3], b[:, :, 3])),
    }

for result in summary['results']:
    scenario = result['scenario']
    images = {
        variant: [np.asarray(Image.open(root / f'{scenario}-{variant}-{i}.png').convert('RGBA'), dtype=np.int16)
                  for i in range(4)]
        for variant in ['baseline', 'candidate']
    }
    assert all(image.shape == (760, 1000, 4) for group in images.values() for image in group)
    control = [compare(a, b) for a, b in combinations(images['baseline'], 2)]
    candidate = [compare(a, b) for a in images['baseline'] for b in images['candidate']]
    measured = {
        'baseline_max_rgb_delta': max(row['max_rgb_delta'] for row in control),
        'candidate_max_rgb_delta': max(row['max_rgb_delta'] for row in candidate),
        'alpha_equal': all(row['alpha_equal'] for row in control + candidate),
        'baseline_max_changed_pixels': max(row['changed_pixels'] for row in control),
        'candidate_max_changed_pixels': max(row['changed_pixels'] for row in candidate),
        'total_pixels': 1000 * 760,
    }
    assert measured == result['pixel_repeatability'], (scenario, measured, result['pixel_repeatability'])
    assert measured['candidate_max_rgb_delta'] <= measured['baseline_max_rgb_delta']
    assert measured['alpha_equal']
    results.append({'scenario': scenario, **measured, 'matches_browser_measurement': True})

report = {'method': 'Independent decoding of all 24 archived PNGs; six baseline pairs and sixteen candidate/baseline pairs per specimen',
          'python': sys.version.split()[0], 'pillow': PIL.__version__, 'numpy': np.__version__,
          'results': results, 'passed': True}
(root / 'independent-pixel-check.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(report, indent=2))
