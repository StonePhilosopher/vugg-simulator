import fs from 'node:fs';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
const root='archive/performance/contact-geometry-lifecycle-2026-10-16';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const manifest=JSON.parse(fs.readFileSync(root+'/files.json'));
const identity=JSON.parse(fs.readFileSync(root+'/identity.json'));
const expected={...identity.inputs,...Object.fromEntries(Object.entries(manifest).map(([name,record])=>[root+'/'+name,record.sha256])),
  [root+'/files.json']:sha(fs.readFileSync(root+'/files.json'))};
const paths=Object.keys(expected);
const bytes=execFileSync('git',['cat-file','--batch'],{input:paths.map(name=>':'+name+'\n').join(''),maxBuffer:128*1024*1024});
let offset=0;
for(const name of paths) {
  const end=bytes.indexOf(10,offset);
  assert.ok(end>=offset,'missing staged header: '+name);
  const header=bytes.subarray(offset,end).toString('utf8');
  const match=/^[0-9a-f]+ blob (\d+)$/.exec(header);
  assert.ok(match,'missing or invalid staged blob: '+name+' '+header);
  const length=Number(match[1]);offset=end+1;
  assert.equal(sha(bytes.subarray(offset,offset+length)),expected[name],'staged bytes differ from measured/archive bytes: '+name);
  offset+=length;assert.equal(bytes[offset++],10,'invalid batch separator: '+name);
}
assert.equal(offset,bytes.length,'unexpected extra batch output');
console.log(`PASS: all ${paths.length} staged input/archive blobs match the measured hashes, including the archive manifest.`);
