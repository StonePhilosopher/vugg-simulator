import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { gunzipSync } from 'node:zlib';
const root='archive/performance/contact-geometry-lifecycle-2026-10-16';
const read=name=>fs.readFileSync(path.join(root,name));
const json=name=>JSON.parse(read(name));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const manifest=json('files.json');
const archivedFiles=fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(entry=>entry.isFile())
  .map(entry=>path.relative(root,path.join(entry.parentPath,entry.name)).replaceAll('\\','/')).filter(name=>name!=='files.json').sort();
assert.deepEqual(Object.keys(manifest).sort(),archivedFiles,'archive manifest must cover every file');
for(const [name,record] of Object.entries(manifest)) {
  const bytes=read(name);assert.equal(bytes.length,record.bytes,name);assert.equal(sha(bytes),record.sha256,name);
  if(name.endsWith('.gz'))gunzipSync(bytes);
}
const identity=json('identity.json');
assert.equal(sha(gunzipSync(read('benchmark-source.mjs.gz'))),identity.inputs['tools/contact-geometry-lifecycle-benchmark.mjs']);
for(const [name,digest] of Object.entries(identity.inputs))assert.equal(sha(fs.readFileSync(name)),digest,'measured bytes changed: '+name);
const summary=json('summary.json');assert.equal(summary.passed,true);assert.equal(summary.errors.length,0);assert.equal(summary.results.length,3);
for(const result of summary.results) {
  const samples=json(result.scenario+'-samples.json');assert.equal(samples.length,8);
  const reference=JSON.parse(gunzipSync(read(result.scenario+'-mesh-witness.json.gz')));
  const referenceHash=sha(JSON.stringify(reference));
  const baseline=samples.filter(row=>row.variant==='baseline');
  const candidate=samples.filter(row=>row.variant==='candidate');
  for(const variant of [baseline,candidate])assert.deepEqual(variant.map(row=>row.iteration),[0,1,2,3]);
  for(const sample of samples) {
    assert.equal(sample.geometry_sha256,referenceHash);assert.equal(sample.science_unchanged,true);
    assert.equal(sample.geometry_material_metadata_equal,true);assert.equal(sample.camera_and_quality_equal,true);
    assert.deepEqual(sample.quality,baseline[0].quality);
    for(const key of ['calls','triangles','points','lines'])assert.equal(sample.render[key],baseline[0].render[key]);
  }
  assert.deepEqual(result.baseline_geometries,baseline.map(row=>row.memory.geometries));
  assert.deepEqual(result.candidate_geometries,candidate.map(row=>row.memory.geometries));
  assert.ok(baseline.at(-1).memory.geometries>baseline[0].memory.geometries);
  for(const [rows,events] of [[baseline,0],[candidate,1]])for(const row of rows.slice(1)) {
    assert.ok(row.retired_contact_dispose_events.length>0);
    assert.ok(row.retired_contact_dispose_events.every(count=>count===events));
  }
  for(const row of candidate) {assert.deepEqual(row.memory,candidate[0].memory);assert.equal(row.programs,candidate[0].programs);}
  assert.deepEqual(baseline[0].memory,candidate[0].memory);
  const a=baseline.flatMap(row=>row.pixel_comparisons_to_prior_baselines);
  const b=candidate.flatMap(row=>row.pixel_comparisons_to_prior_baselines);
  assert.equal(a.length,6);assert.equal(b.length,16);
  const before=Math.max(...a.map(row=>row.max_rgb_delta)),after=Math.max(...b.map(row=>row.max_rgb_delta));
  assert.ok(after<=before);assert.ok([...a,...b].every(row=>row.alpha_equal));
  assert.equal(result.pixel_repeatability.baseline_max_rgb_delta,before);
  assert.equal(result.pixel_repeatability.candidate_max_rgb_delta,after);
  for(const variant of ['baseline','candidate'])assert.equal(sha(read(result.scenario+'-'+variant+'-0.png')),result.screenshots[variant]);
}
assert.equal(json('independent-pixel-check.json').passed,true);
assert.equal(json('verification.json').focused_tests,93);
assert.equal(json('verification.json').science_tests,55);
assert.equal(json('verification.json').commissioned_browser_checks.length,17);
assert.equal(json('verification.json').final_completion.exit_code,0);
assert.equal(json('scientific-preservation.json').fresh_science_workflow.exit_code,0);
assert.equal(json('scientific-preservation.json').scenario_count,41);
assert.equal(json('scientific-preservation.json').measured_production_bytes_unchanged,true);
for(const key of ['mechanism_results_unchanged','mechanism_payload_unchanged','browser_payload_unchanged','all_claim_cards_unchanged','browser_journeys_unchanged'])assert.equal(json('scientific-preservation.json')[key],true,key);
console.log(`PASS: ${Object.keys(manifest).length} file hashes, exact producer and production inputs, all 24 samples, resource gates, image bounds, and science preservation.`);
