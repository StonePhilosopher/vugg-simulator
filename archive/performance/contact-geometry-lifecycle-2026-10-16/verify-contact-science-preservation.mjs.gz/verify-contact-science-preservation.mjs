import fs from 'node:fs';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';

const base = '59d9c409a79d9631792e789c63248262e5519150';
const helper = JSON.parse(fs.readFileSync('.local-evidence/contact-lifecycle-science-helper.json'));
const completion = JSON.parse(fs.readFileSync('.local-evidence/contact-lifecycle-science-completion.json'));
assert.equal(completion.started_utc, helper.started_utc, 'stale science completion');
assert.equal(completion.exit_code, 0, 'fresh science workflow did not pass');
const sha = text => createHash('sha256').update(text).digest('hex');
const current = file => fs.readFileSync(file, 'utf8').replaceAll('\r\n', '\n');
const previous = file => execFileSync('git', ['show', `${base}:${file}`], {encoding:'utf8',maxBuffer:128*1024*1024}).replaceAll('\r\n','\n');
const files = {};
for (const file of ['tests-js/baselines/seed42_v285.json',
  'tests-js/baselines/locality_frequency_v285.json', 'tests-js/baselines/strip_digest_v285.json', 'js/15-version.ts']) {
  assert.ok(current(file) === previous(file), 'scientific artifact changed: '+file);
  files[file] = { lf_sha256: sha(current(file)), unchanged: true };
}
const scenarios = Object.keys(JSON.parse(current('tests-js/baselines/seed42_v285.json')));
for(const scenario of scenarios) {
  const file = `archive/strips/v285/${scenario}.json`;
  assert.ok(current(file) === previous(file), 'scientific strip changed: '+scenario);
  files[file] = { lf_sha256: sha(current(file)), unchanged: true };
}
const mechanismFile = 'archive/evidence/mechanism-witnesses-v285.json';
const browserFile = 'archive/evidence/guided-tutorial-browser-v285.json';
const beforeBrowser = JSON.parse(previous(browserFile)), afterBrowser = JSON.parse(current(browserFile));
assert.ok(isDeepStrictEqual(afterBrowser.payload.journeys, beforeBrowser.payload.journeys),
  'browser journey payload changed');
const beforeMechanismArtifact = JSON.parse(previous(mechanismFile));
const afterMechanismArtifact = JSON.parse(current(mechanismFile));
const beforeMechanism = beforeMechanismArtifact.payload;
const afterMechanism = afterMechanismArtifact.payload;
const beforeReference = beforeMechanism.guided_tutorial.interaction_products.capable_browser_authority;
const afterReference = afterMechanism.guided_tutorial.interaction_products.capable_browser_authority;
assert.equal(beforeReference.payload_sha256, beforeBrowser.payload_sha256, 'old browser authority reference mismatch');
assert.equal(afterReference.payload_sha256, afterBrowser.payload_sha256, 'new browser authority reference mismatch');
const browserReferenceUpdate = {
  path:'payload.guided_tutorial.interaction_products.capable_browser_authority.payload_sha256',
  before:beforeReference.payload_sha256,after:afterReference.payload_sha256,
  each_matches_corresponding_browser_receipt:true,
};
// The browser receipt is regenerated for the changed runtime; its nested hash must
// follow it. Permit only this verified reference update; compare every result.
afterReference.payload_sha256 = beforeReference.payload_sha256;
assert.ok(isDeepStrictEqual(afterMechanism, beforeMechanism), 'mechanism witness results changed');
let claimCardsUnchanged = true;
for (const scenario of scenarios) for (const extension of ['json','md']) {
  const file = `archive/claim-cards/v285/${scenario}.${extension}`;
  const before = previous(file);
  const expected = before.replaceAll(beforeMechanismArtifact.payload_sha256, afterMechanismArtifact.payload_sha256);
  assert.ok(current(file) === expected, 'claim card changed beyond verified mechanism reference: '+file);
  claimCardsUnchanged &&= current(file) === before;
}
const measurement = JSON.parse(current('archive/performance/contact-geometry-lifecycle-2026-10-16/identity.json'));
for(const file of ['index.html','js/99i-renderer-three.ts','data/scenarios.json5','data/minerals.json','tools/three.module.js']) {
  assert.equal(sha(fs.readFileSync(file)), measurement.inputs[file], 'measured production bytes changed: '+file);
}
const report = { schema:'contact-lifecycle-science-preservation-v1',trust:'preservation-of-commissioned-model-not-independent-geological-validation',
  reference_commit:base,node:process.version,platform:process.platform,arch:process.arch,
  fresh_science_workflow:completion,scenario_count:scenarios.length,files,
  mechanism_results_unchanged:true,browser_authority_reference_update:browserReferenceUpdate,
  mechanism_payload_unchanged:beforeMechanismArtifact.payload_sha256===afterMechanismArtifact.payload_sha256,
  browser_payload_unchanged:beforeBrowser.payload_sha256===afterBrowser.payload_sha256,
  all_claim_cards_unchanged:claimCardsUnchanged,
  all_41_claim_cards_only_update_verified_mechanism_reference:true,
  browser_journeys_unchanged:true,measured_production_bytes_unchanged:true };
fs.writeFileSync('archive/performance/contact-geometry-lifecycle-2026-10-16/scientific-preservation.json',JSON.stringify(report,null,2)+'\n');
console.log(`PASS: ${scenarios.length} full strip archives, all three baseline artifacts, SIM/model identity, mechanism results and browser journeys unchanged; browser authority references authenticated; claim cards unchanged: ${claimCardsUnchanged}.`);
